package com.mingyuechunqiu.recordermanager.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mingyuechunqiu.recordermanager.data.constants.RecorderManagerConstants;

/**
 * <pre>
 *     author : 明月春秋
 *     Github : https://github.com/MingYueChunQiu
 *     e-mail : yujie.xi@ehailuo.com
 *     time   : 2019/1/28
 *     desc   : 录制视频配置信息类
 *     version: 1.0
 * </pre>
 */
public class RecordVideoOption implements Parcelable {

    private final Builder mBuilder;

    public RecordVideoOption() {
        this(new Builder());
    }

    public RecordVideoOption(@NonNull Builder builder) {
        mBuilder = builder;
    }

    protected RecordVideoOption(@NonNull Parcel in) {
        mBuilder = new Builder();
        mBuilder.recorderOption = in.readParcelable(RecorderOption.class.getClassLoader());
        mBuilder.recordVideoButtonOption = in.readParcelable(RecordVideoButtonOption.class.getClassLoader());
        mBuilder.minDuration = in.readInt();
        mBuilder.maxDuration = in.readInt();
        mBuilder.cameraType = RecorderManagerConstants.CameraType.values()[in.readInt()];
        mBuilder.hideFlipCameraButton = in.readByte() != 0;
        mBuilder.hideFlashlightButton = in.readByte() != 0;
        mBuilder.timingHint = in.readString();
        mBuilder.errorToastMsg = in.readString();
    }

    public static final Creator<RecordVideoOption> CREATOR = new Creator<RecordVideoOption>() {
        @Override
        public RecordVideoOption createFromParcel(Parcel in) {
            return new RecordVideoOption(in);
        }

        @Override
        public RecordVideoOption[] newArray(int size) {
            return new RecordVideoOption[size];
        }
    };

    public RecorderOption getRecorderOption() {
        return mBuilder.recorderOption;
    }

    public void setRecorderOption(RecorderOption option) {
        mBuilder.recorderOption = option;
    }

    public RecordVideoButtonOption getRecordVideoButtonOption() {
        return mBuilder.recordVideoButtonOption;
    }

    public void setRecordVideoButtonOption(RecordVideoButtonOption recordVideoButtonOption) {
        mBuilder.recordVideoButtonOption = recordVideoButtonOption;
    }

    public int getMinDuration() {
        return mBuilder.minDuration;
    }

    public void setMinDuration(int minDuration) {
        mBuilder.setMinDuration(minDuration);
    }

    public int getMaxDuration() {
        return mBuilder.maxDuration;
    }

    public void setMaxDuration(int maxDuration) {
        mBuilder.setMaxDuration(maxDuration);
    }

    public RecorderManagerConstants.CameraType getCameraType() {
        return mBuilder.cameraType;
    }

    public void setCameraType(RecorderManagerConstants.CameraType cameraType) {
        mBuilder.cameraType = cameraType;
    }

    public boolean isHideFlipCameraButton() {
        return mBuilder.hideFlipCameraButton;
    }

    public void setHideFlipCameraButton(boolean hideFlipCameraButton) {
        mBuilder.hideFlipCameraButton = hideFlipCameraButton;
    }

    public boolean isHideFlashlightButton() {
        return mBuilder.hideFlashlightButton;
    }

    public void setHideFlashlightButton(boolean hideFlashlightButton) {
        mBuilder.hideFlashlightButton = hideFlashlightButton;
    }

    @Nullable
    public String getTimingHint() {
        return mBuilder.timingHint;
    }

    public void setTimingHint(@Nullable String timingHint) {
        mBuilder.timingHint = timingHint;
    }

    @Nullable
    public String getErrorToastMsg() {
        return mBuilder.errorToastMsg;
    }

    public void setErrorToastMsg(@Nullable String errorToastMsg) {
        mBuilder.errorToastMsg = errorToastMsg;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(mBuilder.recorderOption, flags);
        dest.writeParcelable(mBuilder.recordVideoButtonOption, flags);
        dest.writeInt(mBuilder.minDuration);
        dest.writeInt(mBuilder.maxDuration);
        dest.writeInt(mBuilder.cameraType.ordinal());
        dest.writeByte((byte) (mBuilder.hideFlipCameraButton ? 1 : 0));
        dest.writeByte((byte) (mBuilder.hideFlashlightButton ? 1 : 0));
        dest.writeString(mBuilder.timingHint);
        dest.writeString(mBuilder.errorToastMsg);
    }

    /**
     * 链式调用
     */
    public static class Builder {

        private RecorderOption recorderOption;//录制配置信息
        private RecordVideoButtonOption recordVideoButtonOption;//录制视频按钮配置信息类
        private int minDuration;//最小录制时长（秒数，最小是1，会自动调整不大于最大录制时长），可以和timingHint配合使用
        private int maxDuration;//最大录制时间（秒数）
        private RecorderManagerConstants.CameraType cameraType;//摄像头类型
        private boolean hideFlipCameraButton;//隐藏返回翻转摄像头按钮
        private boolean hideFlashlightButton;//隐藏闪光灯按钮
        private String timingHint;//录制按钮上方提示语句（默认：0：%s）,会在计时前显示
        private String errorToastMsg;//录制发生错误Toast（默认：录制时间小于1秒，请重试）

        public Builder() {
            minDuration = 1;//最小1秒
            maxDuration = 30;//默认30秒
            cameraType = RecorderManagerConstants.CameraType.CAMERA_NOT_SET;
        }

        public RecordVideoOption build() {
            return new RecordVideoOption(this);
        }

        public RecorderOption getRecorderOption() {
            return recorderOption;
        }

        public Builder setRecorderOption(RecorderOption option) {
            this.recorderOption = option;
            return this;
        }

        public RecordVideoButtonOption getRecordVideoButtonOption() {
            return recordVideoButtonOption;
        }

        public Builder setRecordVideoButtonOption(RecordVideoButtonOption recordVideoButtonOption) {
            this.recordVideoButtonOption = recordVideoButtonOption;
            return this;
        }

        public int getMinDuration() {
            return minDuration;
        }

        public Builder setMinDuration(int minDuration) {
            if (minDuration > 1) {
                this.minDuration = minDuration;
            }
            if (this.minDuration > maxDuration) {
                this.minDuration = maxDuration;
            }
            return this;
        }

        public int getMaxDuration() {
            return maxDuration;
        }

        public Builder setMaxDuration(int maxDuration) {
            if (maxDuration > 1) {
                this.maxDuration = maxDuration;
            }
            if (minDuration > maxDuration) {
                minDuration = maxDuration;
            }
            return this;
        }

        public RecorderManagerConstants.CameraType getCameraType() {
            return cameraType;
        }

        public Builder setCameraType(RecorderManagerConstants.CameraType cameraType) {
            this.cameraType = cameraType;
            return this;
        }

        public boolean isHideFlipCameraButton() {
            return hideFlipCameraButton;
        }

        public Builder setHideFlipCameraButton(boolean hideFlipCameraButton) {
            this.hideFlipCameraButton = hideFlipCameraButton;
            return this;
        }

        public boolean isHideFlashlightButton() {
            return hideFlashlightButton;
        }

        public Builder setHideFlashlightButton(boolean hideFlashlightButton) {
            this.hideFlashlightButton = hideFlashlightButton;
            return this;
        }

        @Nullable
        public String getTimingHint() {
            return timingHint;
        }

        public Builder setTimingHint(@Nullable String timingHint) {
            this.timingHint = timingHint;
            return this;
        }

        @Nullable
        public String getErrorToastMsg() {
            return errorToastMsg;
        }

        public Builder setErrorToastMsg(@Nullable String errorToastMsg) {
            this.errorToastMsg = errorToastMsg;
            return this;
        }
    }
}
