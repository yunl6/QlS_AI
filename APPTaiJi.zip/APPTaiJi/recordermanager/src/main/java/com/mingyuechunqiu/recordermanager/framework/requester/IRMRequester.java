package com.mingyuechunqiu.recordermanager.framework.requester;

/**
 * <pre>
 *      Project:    RecorderManager
 *
 *      Author:     MingYueChunQiu
 *      Github:     https://github.com/MingYueChunQiu
 *      Email:      xiyujieit@163.com
 *      Time:       2020/5/22 9:12 PM
 *      Desc:       库请求者类父接口
 *      Version:    1.0
 * </pre>
 */
public interface IRMRequester {
}
