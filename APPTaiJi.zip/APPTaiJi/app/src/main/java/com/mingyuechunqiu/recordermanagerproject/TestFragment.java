package com.mingyuechunqiu.recordermanagerproject;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.MediaStore;
import android.security.FileIntegrityManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.youth.banner.Banner;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.BitmapCallback;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TestFragment extends Fragment {
    private AppCompatButton btnVideo,btnVideo2,btnVideoRe,btnup1,btnup2;
    private Button btnip;
    private EditText editip;
    private ImageView Imgai;
    private TextView mtxt;
    private String Nurl="";
    private  String Urlip="http://";
    private String Urlselvet="/QLS_TaiJi/servlet/";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main, container, false);
        doBanner(view);
        initview(view);
        ViewSet();
        return view;
    }

    private void ViewSet() {
        btnVideo.setOnClickListener(this::onClik);
        btnVideo2.setOnClickListener(this::onClik);
        btnVideoRe.setOnClickListener(this::onClik);
        btnup1.setOnClickListener(this::onClik);
        btnup2.setOnClickListener(this::onClik);
        btnip.setOnClickListener(this::onClik);
    }

    public void onClik(View view){

        switch (view.getId()){
            case R.id.btn_main_system_record_video:
                doVideo(1);
                break;
            case  R.id.btn_video2:
                doVideo(2);
                break;
            case R.id.btn_receive:
                Receive();
                break;
            case R.id.btn_updz1:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        uploaddz( 1);
                    }
                }).start();
                break;
            case R.id.btn_updz2:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        uploaddz( 2);
                    }
                }).start();
                break;
            case R.id.btn_ip:
                urltext();
                break;
            default:
                break;
        }

    }

    private void urltext() {
        if(!editip.getText().toString().equals("")) {
            Nurl=Urlip+editip.getText().toString()+Urlselvet;
            System.out.println(Nurl);
        }
    }

    private void uploaddz(int i) {
        OkHttpClient mOkHttpClent = new OkHttpClient();
     switch (i){
         case 1:
             File file = new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera/TS.mp4");
             MultipartBody.Builder builder = new MultipartBody.Builder()
                     .setType(MultipartBody.FORM)
                     .addFormDataPart("mp4", "TS.mp4",
                             RequestBody.create(MediaType.parse("video/mp4"), file));
             RequestBody requestBody = builder.build();
             Request request = new Request.Builder()
                     .url(Nurl+"UploadHandleServlet")
                     .post(requestBody)
                     .build();
             Call call = mOkHttpClent.newCall(request);
             call.enqueue(new Callback() {
                 @Override
                 public void onFailure(Call call, IOException e) {
                 }
                 @Override
                 public void onResponse(Call call, Response response) throws IOException {
                 }
             });
             countDownTimer.start();
             break;
         case 2:
             File file1 = new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera/GT.mp4");
             MultipartBody.Builder builder1 = new MultipartBody.Builder()
                     .setType(MultipartBody.FORM)
                     .addFormDataPart("mp4", "GT.mp4",
                             RequestBody.create(MediaType.parse("video/mp4"), file1));
             RequestBody requestBody1 = builder1.build();
             Request request1 = new Request.Builder()
                     .url(Nurl+"UploadHandleServlet2")
                     .post(requestBody1)
                     .build();
             Call call1 = mOkHttpClent.newCall(request1);
             call1.enqueue(new Callback() {
                 @Override
                 public void onFailure(Call call, IOException e) {
                 }
                 @Override
                 public void onResponse(Call call, Response response) throws IOException {
                 }
             });
             countDownTimer.start();
             break;
         default:
             break;
     }
    }
    private CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            long time = millisUntilFinished / 1000;
            mtxt.setText(time + "s");
            mtxt.setClickable(false);
        }

        @Override
        public void onFinish() {
            mtxt.setText("Receive\nthe result");
            mtxt.setClickable(true);
        }
    };
    private void Receive() {
        OkHttpUtils.get().url(Urlip+editip.getText().toString()+"/QLS_TaiJi/TSdz/rece.jpg").build().execute(new BitmapCallback() {
            @Override
            public void onError(Call call, Exception e, int id) {
            }

            @Override
            public void onResponse(Bitmap response, int id) {
                try {

                    Imgai.setImageBitmap(response);

                }catch (Exception e){
                }
            }
        });

    }
    private  void doVideo(int i) {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if(Build.VERSION.SDK_INT < 24){
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
                    Environment.getExternalStorageDirectory(), "/DCIM/Camera/demo.mp4")));
        }else{
switch (i){
    case 1:

        Uri uri= FileProvider.getUriForFile(getActivity(),"com.mingyuechunqiu.recordermanagerproject.fileprovider",new File(
                Environment.getExternalStorageDirectory(), "/DCIM/Camera/TS.mp4"));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION );
        //添加这一句表示对目标应用临时授权该Uri所代表的文件
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);

        break;
    case 2:

        Uri uri2= FileProvider.getUriForFile(getActivity(),"com.mingyuechunqiu.recordermanagerproject.fileprovider",new File(
                Environment.getExternalStorageDirectory(), "/DCIM/Camera/GT.mp4"));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION );
        //添加这一句表示对目标应用临时授权该Uri所代表的文件
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri2);
        break;
    default:
        break;
}
            //设置视频录制的最长时间,
            intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 7);
            //保存路径
            intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            startActivityForResult(intent, 0);
        }



        }
    private void initview(View  view) {
        btnVideo = view.findViewById(R.id.btn_main_system_record_video);
        btnVideo2 = view.findViewById(R.id.btn_video2);
        btnVideoRe = view.findViewById(R.id.btn_receive);
        mtxt=view.findViewById(R.id.jishi);
        Imgai=view.findViewById(R.id.img_ai);
        btnup1=view.findViewById(R.id.btn_updz1);
        btnup2=view.findViewById(R.id.btn_updz2);
        btnip=view.findViewById(R.id.btn_ip);
        editip=view.findViewById(R.id.edit_ip);
    }
    private void doBanner(View view) {
        List images = new ArrayList();
        images.add("http://www.6okok.com/uploads/allimg/180812/1-1PQ20S233O2.jpg");
        images.add("http://www.6okok.com/uploads/allimg/180812/1-1PQ20S351R3.jpg");
        images.add("http://www.6okok.com/uploads/allimg/200318/1-20031P63315452.jpg");
        Banner banner = view.findViewById(R.id.banner);
        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(images);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
    }
    @Override
    public void onDestroy() {
        //销毁计时器
        countDownTimer.cancel();
        countDownTimer.onFinish();
        countDownTimer = null;
        super.onDestroy();
    }
}
